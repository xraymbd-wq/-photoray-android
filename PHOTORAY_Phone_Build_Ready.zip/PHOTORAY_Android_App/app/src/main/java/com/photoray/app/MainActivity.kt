package com.photoray.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.View
import android.widget.*
import android.webkit.*

class MainActivity : Activity() {
    private lateinit var browser: WebView
    private lateinit var progress: ProgressBar
    private lateinit var error: LinearLayout
    private val home = "https://photoray.infinityfree.me/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        browser = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        error = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
            val message = TextView(context).apply { text = "Unable to load PHOTORAY. Check your connection."; textSize = 17f; gravity = android.view.Gravity.CENTER; setPadding(32, 16, 32, 16) }
            val retry = Button(context).apply { text = "Retry"; setOnClickListener { visibility = View.GONE; browser.reload() } }
            addView(message); addView(retry)
        }
        root.addView(browser)
        root.addView(error, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress, FrameLayout.LayoutParams(-1, 5, android.view.Gravity.TOP))
        setContentView(root)
        browser.settings.javaScriptEnabled = true
        browser.settings.domStorageEnabled = true
        browser.settings.loadsImagesAutomatically = true
        browser.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        browser.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) { progress.progress = newProgress; progress.visibility = if (newProgress == 100) View.GONE else View.VISIBLE }
        }
        browser.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (!request.isForMainFrame) return false
                if (uri.scheme == "https" && uri.host.equals("photoray.infinityfree.me", true)) return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (_: Exception) { true }
            }
            override fun onPageFinished(view: WebView?, url: String?) { /* Page loaded */ }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, failure: WebResourceError?) {
                if (request?.isForMainFrame == true) error.visibility = View.VISIBLE
            }
            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, response: WebResourceResponse?) {
                if (request?.isForMainFrame == true && (response?.statusCode ?: 0) >= 400) error.visibility = View.VISIBLE
            }
        }
        browser.loadUrl(home)
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (error.visibility == View.VISIBLE) { error.visibility = View.GONE; browser.loadUrl(home) } else if (browser.canGoBack()) browser.goBack() else super.onBackPressed() }
    override fun onDestroy() { browser.destroy(); super.onDestroy() }
}
