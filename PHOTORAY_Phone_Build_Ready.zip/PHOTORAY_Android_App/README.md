# PHOTORAY™ Android app

This Android Studio source project wraps https://photoray.infinityfree.me/ in a WebView and includes the user-supplied PHOTORAY™ logo as the app launcher icon and splash background.

## Build
1. Open the PHOTORAY_Android_App directory in Android Studio.
2. Install Android SDK 35 and let Gradle sync (internet required).
3. Use Build > Build APK(s) to test on Android.
4. For Google Play, use Build > Generate Signed App Bundle / APK > Android App Bundle. Protect your signing key.

The app has NOT been compiled or tested here. Test on physical devices, including links, media, and WebView access to InfinityFree hosting. Google Play approval is not guaranteed, especially for simple website wrappers. A privacy policy, store listing, Play Console account, and compliance checks may be required.
